<?php
/**
 * Created by sonmobi@gmail.com
 * Date: 12/10/2017
 * Time: 4:47 PM
 */

class DemoModel extends Model{

    public function loadList($params = null)
    {
        // TODO: Implement loadList() method.

        return "123";
    }

    public function count($params = null)
    {
        // TODO: Implement count() method.
    }

    public function loadOne($id)
    {
        // TODO: Implement loadOne() method.
    }

}