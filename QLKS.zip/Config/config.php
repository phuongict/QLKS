<?php
define('_article_limit',4);
define('_product_limit',8);
define('_admin_page_limit',10);
//define('_base_path','http://localhost:8055/bandouong/index.php');
//define('_app_path_images_public','/public/frontend/images');
define('template_url','public/backend/');